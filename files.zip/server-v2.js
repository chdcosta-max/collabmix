/**
 * COLLAB//MIX — WebSocket Sync + WebRTC Signaling Server
 * Handles both DJ state sync AND WebRTC offer/answer/ICE relay
 */

const WebSocket = require("ws");
const http = require("http");

const PORT = process.env.PORT || 8080;
const rooms = new Map();
let djCounter = 0;

function generateDjId() {
  return `dj_${++djCounter}_${Math.random().toString(36).slice(2, 6)}`;
}

function getRoomOrCreate(roomId) {
  if (!rooms.has(roomId)) rooms.set(roomId, { djs: new Map() });
  return rooms.get(roomId);
}

function broadcastToRoom(room, senderId, message) {
  const payload = JSON.stringify(message);
  for (const [djId, dj] of room.djs) {
    if (djId !== senderId && dj.ws.readyState === WebSocket.OPEN) {
      dj.ws.send(payload);
    }
  }
}

function sendTo(ws, message) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message));
}

function getPartner(room, djId) {
  for (const [id, dj] of room.djs) {
    if (id !== djId) return { id, ...dj };
  }
  return null;
}

const httpServer = http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.url === "/health") {
    const djCount = [...rooms.values()].reduce((s, r) => s + r.djs.size, 0);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok", rooms: rooms.size, djs: djCount, uptime: process.uptime() }));
  } else {
    res.writeHead(200); res.end("COLLAB//MIX Server");
  }
});

const wss = new WebSocket.Server({ server: httpServer });

wss.on("connection", (ws) => {
  let djId = null, roomId = null;

  ws.on("message", (raw) => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    const { type } = msg;

    // ── JOIN ─────────────────────────────────────────────────
    if (type === "join") {
      const { roomId: rid, djName } = msg;
      if (!rid || !djName) return;
      const room = getRoomOrCreate(rid);
      if (room.djs.size >= 2) { sendTo(ws, { type: "error", msg: "Room full" }); return; }

      djId = generateDjId(); roomId = rid;
      const initialState = { deckA: {}, deckB: {}, xfade: 0.5 };
      room.djs.set(djId, { ws, name: djName, state: initialState });

      const partner = getPartner(room, djId);
      sendTo(ws, { type: "joined", djId, roomId, djName, partnerName: partner?.name || null, partnerState: partner?.state || null });
      if (partner) sendTo(partner.ws, { type: "partner_joined", djName });
      console.log(`[join] ${djName} → room ${roomId} (${room.djs.size}/2)`);
      return;
    }

    if (!djId || !roomId) return;
    const room = rooms.get(roomId); if (!room) return;
    const me = room.djs.get(djId); if (!me) return;

    // ── DJ STATE SYNC ────────────────────────────────────────
    if (type === "deck_update") {
      const { deckId, field, value } = msg;
      const key = `deck${deckId}`;
      if (me.state[key]) me.state[key][field] = value;
      broadcastToRoom(room, djId, { type, from: me.name, deckId, field, value });
      return;
    }

    if (type === "xfade_update") {
      me.state.xfade = msg.value;
      broadcastToRoom(room, djId, { type, from: me.name, value: msg.value });
      return;
    }

    if (type === "chat") {
      const time = new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
      const chatMsg = { type, from: me.name, msg: msg.msg, time };
      broadcastToRoom(room, djId, chatMsg);
      sendTo(ws, { ...chatMsg, self: true });
      return;
    }

    if (type === "sync_request") {
      const partner = getPartner(room, djId);
      if (partner) sendTo(partner.ws, { type, from: me.name });
      return;
    }

    if (type === "sync_response") {
      broadcastToRoom(room, djId, { type, from: me.name, state: msg.state });
      return;
    }

    if (type === "ping") {
      sendTo(ws, { type: "pong", clientTime: msg.clientTime, serverTime: Date.now() });
      return;
    }

    // ── WEBRTC SIGNALING ─────────────────────────────────────
    // Server is a pure relay for WebRTC — just forward to partner
    if (["rtc_offer", "rtc_answer", "rtc_ice", "rtc_hangup", "library_sync"].includes(type)) {
      broadcastToRoom(room, djId, { ...msg, from: me.name });
      console.log(`[rtc] ${me.name} → ${type}`);
      return;
    }
  });

  ws.on("close", () => {
    if (!djId || !roomId) return;
    const room = rooms.get(roomId); if (!room) return;
    const me = room.djs.get(djId);
    room.djs.delete(djId);
    broadcastToRoom(room, djId, { type: "partner_left", djName: me?.name });
    // Also send hangup so remote WebRTC connection tears down cleanly
    broadcastToRoom(room, djId, { type: "rtc_hangup", from: me?.name });
    if (room.djs.size === 0) rooms.delete(roomId);
    console.log(`[leave] ${me?.name} left room ${roomId}`);
  });

  ws.on("error", (err) => console.error(`[ws error] ${err.message}`));
});

httpServer.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║   COLLAB//MIX  —  v2 with WebRTC    ║`);
  console.log(`╠══════════════════════════════════════╣`);
  console.log(`║  WS   → ws://localhost:${PORT}         ║`);
  console.log(`║  HTTP → http://localhost:${PORT}/health ║`);
  console.log(`╚══════════════════════════════════════╝\n`);
});
